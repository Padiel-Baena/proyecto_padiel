package tema3;
// Escribe un programa que muestre las tablas de multiplicar del 1 al 10.
public class E6 {
    public static void main(String[] args) {
        System.out.println("Te voy a decir las tablas del 1 al 10");
        int num = 1;
        int n = 1;
        for(num = 1; num < 11; num++) {
                    E5.tabla2(num);
        }
    }
}
